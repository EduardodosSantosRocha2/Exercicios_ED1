
package com.mycompany.dinossauro;

public class Herbivoro extends Dinossauro {
     private  float peso;

    public Herbivoro(String nome, int codigo,float peso) {
        super(nome, codigo);
        this.peso = peso;
    }

    public float getPeso() {
        return peso;
    }

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public int getCodigo() {
        return codigo;
    }
     
  
    @Override
    public String toString() {
        return "Herbivoro:\n"+super.toString() + "peso=" + peso + "\n";
    }

    
    
    
}
