package com.mycompany.dinossauro;

public class Carnivoro extends Dinossauro{
     private String alimento;

    public Carnivoro(String nome, int codigo, String alimento) {
        super(nome, codigo);
        this.alimento = alimento;
    }

    public String getAlimento() {
        return alimento;
    }

    public String getNome() {
        return nome;
    }

    @Override
    public int getCodigo() {
        return codigo;
    }

     @Override
    public String toString() {
        return "Herbivoro:\n"+super.toString() + "Alimento=" + alimento + "\n";
    }
 
    
}
