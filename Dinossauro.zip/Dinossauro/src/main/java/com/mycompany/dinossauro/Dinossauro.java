package com.mycompany.dinossauro;

import java.util.logging.Logger;

public abstract class Dinossauro {
    public String nome;
    public int codigo;

    public Dinossauro(String nome, int codigo) {
        this.nome = nome;
        this.codigo = codigo;
    }

    
    
   

    public String getNome() {
        return nome;
    }

    public int getCodigo() {
        return codigo;
    } 


    
    public void Printar(){
        
    }

    @Override
    public String toString() {
        return "Dinossauro:\n" + "Nome=" + nome + "\nCodigo=" + codigo +"\n";
    }

    
    
    
       
}