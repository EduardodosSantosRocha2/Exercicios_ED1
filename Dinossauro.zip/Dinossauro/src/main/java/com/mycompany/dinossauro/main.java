package com.mycompany.dinossauro;

import java.util.Scanner;

public class main {

    public static void main(String[] args) {
        boolean flag = true, flagaux = true;
        String nome, alimento;
        boolean aux = false;
        int cod, i, pos = 0, posc = 0, opc, codex, codcs;
        float peso;
        char escolha;
        Dinossauro d[] = new Dinossauro[10];

        Scanner ler = new Scanner(System.in);
        Scanner lerstr = new Scanner(System.in);
        Scanner lerstr1 = new Scanner(System.in);
        
        
       
       

        System.out.println("|||||||||||||||||||||||||||||||||||||||||||||||||\n");
        System.out.println("           Jurassic Java Park                      ");
        System.out.println("|||||||||||||||||||||||||||||||||||||||||||||||||\n");

        System.out.println("[1]Cadastrar Hebirvoro:\n[2]Cadastrar Carnivoro:\n[3]Consultar:\n[4]Excluir:\n[0]Sair:");
        opc = ler.nextInt();

        while (opc != 0) {
            switch (opc) {
                case 1:
                    if (pos == 0) {

                        System.out.println("Digite o nome do herbivoro\n");
                        nome = lerstr.nextLine();

                        System.out.println("Digite o peso do herbivoro\n");
                        peso = ler.nextFloat();
                        while (peso < 0) {
                            System.out.println("Erro!\nDigite um peso Valido!\n");
                            peso = ler.nextFloat();
                        }

                        System.out.println("Digite o codigo do herbivoro\n");
                        cod = ler.nextInt();

                        d[pos] = new Herbivoro(nome, cod, peso);
                        
                        pos++;
                        

                    } else {

                        System.out.println("Digite o nome do herbivoro\n");
                        nome = lerstr1.nextLine();

                        for (i = 0; i < pos; i++) {
                            if (nome.equals(d[i].getNome())) {
                                aux = true;
                            }
                        }
                        ler.nextLine();
                        while (aux != false) {
                            System.out.println("Erro nome duplicado!\nDigite o nome do herbivoro");
                            nome = ler.nextLine();
                            for (i = 0; i < pos; i++) {
                                if (nome.equals(d[i].getNome())) {
                                    aux = true;
                                } else {
                                    aux = false;
                                }
                            }
                        }

                        System.out.println("Digite o peso do herbivoro\n");
                        peso = ler.nextFloat();
                        while (peso < 0) {
                            System.out.println("Erro!\nDigite um peso Valido!\n");
                            peso = ler.nextFloat();
                        }

                        System.out.println("Digite o codigo do herbivoro\n");
                        cod = ler.nextInt();

                        d[pos] = new Herbivoro(nome, cod, peso);
                        pos++;

                    }

                    System.out.println("[1]Cadastrar Hebirvoro:\n[2]Cadastrar Carnivoro:\n[3]Consultar:\n[4]Excluir:\n[0]Sair:");
                    opc = lerstr.nextInt();

                    break;
                case 2:
                    ler.nextLine();
                    if (pos == 0) {

                        System.out.println("Digite o nome do carnivoro\n");
                        nome = lerstr.nextLine();

                        System.out.println("Digite o alimento do carnivoro\n");
                        alimento = ler.nextLine();

                        System.out.println("Digite o codigo do carnivoro\n");
                        cod = ler.nextInt();

                        d[pos] = new Carnivoro(nome, cod, alimento);
                        pos++;

                    } else {

                        System.out.println("Digite o nome do carnivoro\n");
                        nome = ler.nextLine();

                        for (i = 0; i < pos; i++) {
                            if (nome.equals(d[i].getNome())) {
                                aux = true;
                            }
                        }

                        while (aux == true) {
                            System.out.println("Erro nome duplicado!\nDigite o nome do carnivoro");
                            nome = ler.nextLine();

                            for (i = 0; i < pos; i++) {
                                if (nome.equals(d[i].getNome())) {
                                    aux = true;
                                } else {
                                    aux = false;
                                }
                            }
                        }

                        ler.nextLine();
                        System.out.println("Digite o alimento do carnivoro\n");
                        alimento = ler.nextLine();

                        System.out.println("Digite o codigo do carnivoro\n");
                        cod = ler.nextInt();

                        d[pos] = new Carnivoro(nome, cod, alimento);
                        pos++;

                    }

                    System.out.println("[1]Cadastrar Hebirvoro:\n[2]Cadastrar Carnivoro:\n[3]Consultar:\n[4]Excluir:\n[0]Sair:");
                    opc = lerstr.nextInt();

                    break;

                case 3:
                    System.out.println("Digite o codigo da especime que deseja consultar: \n");
                    codcs = ler.nextInt();

                    for (i = 0; i < pos; i++) {
                        if (codcs == d[i].getCodigo()) {
                            System.out.println(d[i].toString());
                            i = pos;
                        } else {
                            flag = false;
                        }                                                
                    }                  
                    System.out.println("[1]Cadastrar Hebirvoro:\n[2]Cadastrar Carnivoro:\n[3]Consultar:\n[4]Excluir:\n[0]Sair:");
                    opc = lerstr.nextInt();
                    break;
                

                case 4:
                    System.out.println("Digite o codigo da especime que deseja excluir: \n");
                    codex = ler.nextInt();
                    for (i = 0; i < pos; i++) {
                        if (d[i].getCodigo() == codex) {
                            d[i] = d[pos - 1];
                            d[pos - 1] = null;
                            pos--;
                        }                        
                    }

                     
                    System.out.println("A especime foi extinta!\n");
                    
                    System.out.println("[1]Cadastrar Hebirvoro:\n[2]Cadastrar Carnivoro:\n[3]Consultar:\n[4]Excluir:\n[0]Sair:");
                    opc = lerstr.nextInt();
                    break;

                default:
                    System.out.println("Não existe!");
                    break;
            }

        }

    }

}
