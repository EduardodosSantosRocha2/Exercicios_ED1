
import java.util.Scanner;


public class Aluno extends Pessoa{
  private String matricula;
  private float nota;
  private String curso;
  
  
  @Override
 public void cadastrar(){
     super.cadastrar();
     Scanner Ler = new Scanner(System.in);
     
     
     System.out.println("Digite a matricula: ");
     matricula = Ler.nextLine();
     Ler.nextLine();
     
     System.out.println("Digite a nota: ");
     nota = Ler.nextFloat();
     
     System.out.println("Digite o curso: ");
     curso = Ler.nextLine();    
    }

  @Override
     protected void imprimir(){
         super.imprimir();
         System.out.printf("****************************************************\n");
         System.out.printf("Sua matricula: %s\nSua nota: %f \nSeu curso: %s\n", matricula, nota, curso);
         System.out.printf("****************************************************\n");
     }


}
