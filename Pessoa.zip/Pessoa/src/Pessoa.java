
import java.util.Scanner;

public class Pessoa {
    private String nome;
    private String cpf;
    private int idade;
    
    protected void cadastrar(){
     Scanner Ler = new Scanner(System.in);
     System.out.println("Digite o nome: ");
     nome = Ler.nextLine();
     System.out.println("Digite o cpf: ");
     cpf = Ler.nextLine();
     System.out.println("Digite a idade: ");
     idade = Ler.nextInt();    
    }
   
    
    protected void imprimir(){
        System.out.printf("****************************************************\n");
        System.out.printf("O nome: %s\nO CPF: %s\nA idade: %d", nome, cpf, idade);
        System.out.printf("****************************************************\n");
    }




}
