public class TestePessoa {
    public static void main(String[] args){
        Pessoa p = new Pessoa();
        Aluno a1 = new Aluno();
        Aluno a2 = new Aluno();
        Aluno a3 = new Aluno();
        
        Professor prof = new Professor();
    System.out.println("Pessoa: \n");    
        p.cadastrar();
        p.imprimir();
     
    System.out.println("Alunos: \n");    
        a1.cadastrar();
        a1.imprimir();
     
        a2.cadastrar();
        a2.imprimir();
    
      
        a3.cadastrar();
        a3.imprimir();
     
    System.out.println("Professor: \n");
        prof.cadastrar();
        prof.imprimir();
        
        
        
    }
}
