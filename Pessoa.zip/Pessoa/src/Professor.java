
import java.util.Scanner;

public class Professor extends Pessoa {
    private  String matricula;
    private String materia;
    
 @Override
 public void cadastrar(){
     super.cadastrar();
     Scanner Ler = new Scanner(System.in);
     
     
     System.out.println("Digite a matricula: ");
     matricula = Ler.nextLine();
     Ler.nextLine();
     
     System.out.println("Digite a materia: ");
     materia = Ler.nextLine();
     
      
    }

  @Override
     protected void imprimir(){
         super.imprimir();
         System.out.printf("****************************************************\n");
         System.out.printf("Sua matricula: %s\nSua materia: %s\n",matricula, materia);
         System.out.printf("****************************************************\n");
     }
}
